package com.rk.domain;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class License {
	@Id
	@GenericGenerator(name="gen1",
    strategy="sequence",
    parameters={@Parameter(name="sequence",value="myseq1")})
@GeneratedValue(generator="gen1")
	@Column(name="license_id")
	private int id;
	private String type;
    @Column(name="valid_from")	
	private Date  dateFrom;
    @Column(name="valid_to")
	private Date  dateTo;
    @OneToOne(targetEntity=Person.class,cascade=CascadeType.ALL)
    @JoinColumn(name="license_holder",referencedColumnName="person_id")
	private Person licenseHolder;
	
	
	
	public License() {
	 System.out.println("License:0-param cosntructor");
	}



	public License(int id, String type, Date dateFrom, Date dateTo) {
		System.out.println("License:4-param constructor");
		this.id = id;
		this.type = type;
		this.dateFrom = dateFrom;
		this.dateTo = dateTo;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public Date getDateFrom() {
		return dateFrom;
	}



	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}



	public Date getDateTo() {
		return dateTo;
	}



	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}



	public Person getLicenseHolder() {
		return licenseHolder;
	}



	public void setLicenseHolder(Person licenseHolder) {
		this.licenseHolder = licenseHolder;
	}



	@Override
	public String toString() {
		return "License [id=" + id + ", type=" + type + ", dateFrom="
				+ dateFrom + ", dateTo=" + dateTo + "]";
	}
	
}

/*  create table Person(person_id number(5) primary key,
                        firstName varchar2(20),
                        lastName  varchar2(20),
                        age number(3));
   create table License(license_id number(5) primary key,
                        type varchar2(20),
                        valid_From  date,
                        valid_To    date,
                        license_holder number (5) references person(person_id));
                         
   create sequence my_seq1 increment by 1 start with 1001                                               
                                        
   
 */


