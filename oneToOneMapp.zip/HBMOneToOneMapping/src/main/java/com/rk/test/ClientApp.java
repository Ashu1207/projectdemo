package com.rk.test;

import com.rk.dao.O2ODAO;
import com.rk.dao.O2ODAOFactory;

public class ClientApp {
	public static void main(String[] args) {
		// get DAO
		O2ODAO dao=O2ODAOFactory.getInstance();
		dao.insertDataUsingLicense();
		
	}

}
