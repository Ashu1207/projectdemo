package com.rk.dao;

public interface O2ODAO {
	
	public void insertDataUsingLicense();
	//public void ListDataUsingLicense();

}
