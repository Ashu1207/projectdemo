package com.rk.dao;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.rk.domain.License;
import com.rk.domain.Person;
import com.rk.utility.HibernateUtil;


public class O2ODAOImpl implements O2ODAO {

	
	public void insertDataUsingLicense() {
		//Get Session
		Session ses=HibernateUtil.getSession();
		
		//Save objs (child to parent)
		//parent obj
		Person p=new Person();
		p.setFirstName("Raja");
		p.setLastName("Rao");
		p.setAge((byte)20);
		
		
		//child obj
		License l=new License();
		l.setType("2-wheeler");
		l.setDateFrom(new Date());
		l.setDateTo(new Date(145,6,30));
		//set Parent to child
		l.setLicenseHolder(p);
		
		//Only Parent obj
		 Person p1=new Person();
		 p1.setFirstName("Ravi");
		 p1.setLastName("chari");
		 p1.setAge((byte)26);
				
		
		Transaction tx=null;
		try{
		  tx=ses.beginTransaction();
		    //save objs
		   ses.save(l);
		   ses.save(p1);
		  tx.commit();
		}
		catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}

	}

}//class

